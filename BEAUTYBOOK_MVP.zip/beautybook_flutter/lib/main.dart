import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const BeautyBookApp());

class BeautyBookApp extends StatelessWidget {
  const BeautyBookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BEAUTYBOOK',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8E4162)),
        scaffoldBackgroundColor: const Color(0xFFFFFAFC),
        cardTheme: const CardThemeData(elevation: 0, margin: EdgeInsets.zero),
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;
  final pages = const [HomePage(), ShopPage(), BookingsPage(), ProfilePage()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), selectedIcon: Icon(Icons.shopping_bag), label: 'Shop'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Bookings'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final categories = [
      ('Braids', Icons.face_retouching_natural),
      ('Hair', Icons.content_cut),
      ('Nails', Icons.back_hand_outlined),
      ('Makeup', Icons.brush_outlined),
      ('Clothing', Icons.checkroom),
      ('Wigs', Icons.woman_2_outlined),
      ('Shoes', Icons.ice_skating_outlined),
      ('Bags', Icons.shopping_bag_outlined),
    ];
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Row(children: [
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('BEAUTYBOOK', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            Text('Beauty • Fashion • Your Style', style: TextStyle(color: Colors.black54)),
          ])),
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))
        ]),
        const SizedBox(height: 18),
        TextField(
          decoration: InputDecoration(
            hintText: 'Search braids, gowns, wigs, salons...',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF8E4162), Color(0xFFC66A8C)]),
            borderRadius: BorderRadius.circular(24),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Find your next look', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 7),
            Text('Book beauty professionals or shop fashion in one place.', style: TextStyle(color: Colors.white)),
          ]),
        ),
        const SizedBox(height: 24),
        const SectionTitle('Explore'),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          itemCount: categories.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, mainAxisSpacing: 12, crossAxisSpacing: 10),
          itemBuilder: (_, i) => Column(children: [
            CircleAvatar(radius: 27, backgroundColor: const Color(0xFFF7E6ED), child: Icon(categories[i].$2, color: const Color(0xFF8E4162))),
            const SizedBox(height: 5),
            Text(categories[i].$1, style: const TextStyle(fontSize: 12), overflow: TextOverflow.ellipsis)
          ]),
        ),
        const SizedBox(height: 20),
        const SectionTitle('Popular beauty professionals'),
        const SizedBox(height: 10),
        const ProCard(name: 'Yvee Styles', specialty: 'Braids • Hair styling', rating: '4.9', price: 'From 5,000 CFA'),
        const SizedBox(height: 12),
        const ProCard(name: 'Glow Studio', specialty: 'Makeup • Nails', rating: '4.8', price: 'From 4,000 CFA'),
        const SizedBox(height: 22),
        const SectionTitle('Trending fashion'),
        const SizedBox(height: 10),
        SizedBox(height: 195, child: ListView(scrollDirection: Axis.horizontal, children: const [
          ProductCard(name: 'Summer Gown', price: '3,500 CFA', icon: Icons.checkroom),
          ProductCard(name: 'Ladies Bag', price: '7,500 CFA', icon: Icons.shopping_bag),
          ProductCard(name: 'Premium Wig', price: '25,000 CFA', icon: Icons.woman_2_outlined),
        ]))
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold));
}

class ProCard extends StatelessWidget {
  final String name, specialty, rating, price;
  const ProCard({super.key, required this.name, required this.specialty, required this.rating, required this.price});
  @override
  Widget build(BuildContext context) => Card(
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfessionalPage(name: name))),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          const CircleAvatar(radius: 31, backgroundColor: Color(0xFFF7E6ED), child: Icon(Icons.face_3, size: 32)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            Text(specialty, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 5),
            Text('★ $rating   •   $price', style: const TextStyle(fontSize: 12)),
          ])),
          const Icon(Icons.chevron_right)
        ]),
      ),
    ),
  );
}

class Product {
  final String name, price;
  final IconData icon;
  const Product(this.name, this.price, this.icon);
}

const products = [
  Product('Summer Gown', '3,500 CFA', Icons.checkroom),
  Product('Elegant Dress', '6,500 CFA', Icons.checkroom),
  Product('Ladies Handbag', '7,500 CFA', Icons.shopping_bag),
  Product('Premium Wig', '25,000 CFA', Icons.woman_2_outlined),
  Product('Fashion Heels', '9,000 CFA', Icons.ice_skating_outlined),
  Product('Hair Attachment', '1,500 CFA', Icons.face_retouching_natural),
];

class ProductCard extends StatelessWidget {
  final String name, price;
  final IconData icon;
  const ProductCard({super.key, required this.name, required this.price, required this.icon});
  @override
  Widget build(BuildContext context) => Container(
    width: 145, margin: const EdgeInsets.only(right: 12), padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Container(
        width: double.infinity,
        decoration: BoxDecoration(color: const Color(0xFFF7E6ED), borderRadius: BorderRadius.circular(14)),
        child: Icon(icon, size: 52, color: const Color(0xFF8E4162)),
      )),
      const SizedBox(height: 9),
      Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
      Text(price, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF8E4162))),
    ]),
  );
}

class ShopPage extends StatelessWidget {
  const ShopPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Fashion Shop', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const Text('Clothing, wigs, bags, shoes & beauty products', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .78, crossAxisSpacing: 12, mainAxisSpacing: 12),
        itemBuilder: (_, i) {
          final p = products[i];
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductPage(product: p))),
            child: ProductCard(name: p.name, price: p.price, icon: p.icon),
          );
        },
      )
    ],
  );
}

class ProductPage extends StatelessWidget {
  final Product product;
  const ProductPage({super.key, required this.product});
  Future<void> contactSeller() async {
    final uri = Uri.parse('https://wa.me/?text=${Uri.encodeComponent("Hello, I am interested in ${product.name} on BEAUTYBOOK.")}');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Product')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Container(
          width: double.infinity,
          decoration: BoxDecoration(color: const Color(0xFFF7E6ED), borderRadius: BorderRadius.circular(28)),
          child: Icon(product.icon, size: 110, color: const Color(0xFF8E4162)),
        )),
        const SizedBox(height: 20),
        Text(product.name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        Text(product.price, style: const TextStyle(fontSize: 20, color: Color(0xFF8E4162), fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Available • Contact seller to confirm size, colour and delivery.'),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: contactSeller, icon: const Icon(Icons.chat), label: const Text('Order via WhatsApp')))
      ]),
    ),
  );
}

class ProfessionalPage extends StatefulWidget {
  final String name;
  const ProfessionalPage({super.key, required this.name});
  @override State<ProfessionalPage> createState() => _ProfessionalPageState();
}

class _ProfessionalPageState extends State<ProfessionalPage> {
  String service = 'Box Braids';
  DateTime date = DateTime.now().add(const Duration(days: 1));
  String time = '10:00';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.name)),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const CircleAvatar(radius: 52, backgroundColor: Color(0xFFF7E6ED), child: Icon(Icons.face_3, size: 55)),
      const SizedBox(height: 12),
      Center(child: Text(widget.name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
      const Center(child: Text('★ 4.9 • Beauty Professional')),
      const SizedBox(height: 25),
      const SectionTitle('Choose service'),
      DropdownButton<String>(
        value: service, isExpanded: true,
        items: ['Box Braids', 'Knotless Braids', 'Hair Styling', 'Makeup'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => service = v!),
      ),
      const SizedBox(height: 15),
      ListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Appointment date'),
        subtitle: Text('${date.day}/${date.month}/${date.year}'),
        trailing: const Icon(Icons.calendar_month),
        onTap: () async {
          final d = await showDatePicker(context: context, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 180)), initialDate: date);
          if (d != null) setState(() => date = d);
        },
      ),
      const Text('Time', style: TextStyle(fontWeight: FontWeight.bold)),
      Wrap(spacing: 8, children: ['09:00','10:00','12:00','14:00','16:00'].map((t) => ChoiceChip(label: Text(t), selected: time == t, onSelected: (_) => setState(() => time = t))).toList()),
      const SizedBox(height: 25),
      FilledButton(
        onPressed: () {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Booking request sent: $service at $time')));
          Navigator.pop(context);
        },
        child: const Text('Request Booking'),
      )
    ]),
  );
}

class BookingsPage extends StatelessWidget {
  const BookingsPage({super.key});
  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.all(18),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('My Bookings', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      SizedBox(height: 30),
      Center(child: Icon(Icons.calendar_month_outlined, size: 70, color: Colors.black26)),
      SizedBox(height: 12),
      Center(child: Text('Your appointments will appear here.', style: TextStyle(color: Colors.black54))),
    ]),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Text('Profile', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      const ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('Guest User'), subtitle: Text('Customer account')),
      const Divider(),
      ListTile(leading: const Icon(Icons.storefront), title: const Text('Become a seller / professional'), subtitle: const Text('Sell fashion or receive beauty bookings'), onTap: () {}),
      ListTile(leading: const Icon(Icons.favorite_border), title: const Text('Favorites'), onTap: () {}),
      ListTile(leading: const Icon(Icons.language), title: const Text('Language'), subtitle: const Text('English / Français'), onTap: () {}),
      ListTile(leading: const Icon(Icons.help_outline), title: const Text('Help & support'), onTap: () {}),
    ],
  );
}
