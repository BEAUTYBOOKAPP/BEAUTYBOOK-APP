-- BEAUTYBOOK Supabase starter schema
create table profiles (
  id uuid primary key,
  full_name text,
  phone text,
  role text check (role in ('customer','professional','seller','admin')),
  language text default 'en'
);
create table businesses (
  id bigint generated always as identity primary key,
  owner_id uuid references profiles(id),
  name text not null,
  category text not null,
  location text,
  whatsapp text,
  verified boolean default false
);
create table services (
  id bigint generated always as identity primary key,
  business_id bigint references businesses(id) on delete cascade,
  name text not null,
  price_cfa integer not null,
  duration_minutes integer
);
create table products (
  id bigint generated always as identity primary key,
  business_id bigint references businesses(id) on delete cascade,
  name text not null,
  price_cfa integer not null,
  stock integer default 0,
  sizes text[],
  image_url text
);
create table bookings (
  id bigint generated always as identity primary key,
  customer_id uuid references profiles(id),
  business_id bigint references businesses(id),
  service_id bigint references services(id),
  booking_date date not null,
  booking_time time not null,
  status text default 'pending',
  created_at timestamptz default now()
);
