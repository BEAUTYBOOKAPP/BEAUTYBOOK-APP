# BEAUTYBOOK

Beauty + Fashion marketplace MVP for mobile.

## Included
- Beauty professional discovery
- Beauty professional profiles
- Appointment date/time selection
- Clothing, wigs, shoes, bags and beauty-product marketplace
- CFA pricing
- Product detail screen
- WhatsApp ordering
- Customer bookings area
- Seller/professional entry point
- English/French-ready UI structure

## Run
1. Install Flutter SDK and Android Studio.
2. In this folder run:
   flutter pub get
   flutter run

## Production backend recommendation
Use Supabase:
- auth.users
- profiles (id, role, name, phone, language)
- businesses (id, owner_id, name, category, location, whatsapp, verified)
- services (id, business_id, name, price, duration)
- products (id, business_id, name, price, stock, size, image_url)
- availability (id, business_id, date, start_time, end_time)
- bookings (id, customer_id, business_id, service_id, date, time, status)
- favorites (customer_id, business_id/product_id)
- reviews (id, customer_id, business_id, rating, comment)

Before public launch add authentication, database persistence, image upload, moderation,
privacy policy, terms, seller verification, notifications and production analytics.
